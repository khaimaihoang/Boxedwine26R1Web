All portions copyright � 2001-2004 GameHouse, Inc.

Puzzle Inlay is a trademark of GameHouse, Inc.

All software included in this package is the property of GameHouse, Inc., and
is licensed to an individual user for a limited time, or perpetually if product
is registered. All rights are reserved by GameHouse.

For support issues relating to the operation of this software, please use our
customer product support form located at: http://www.gamehouse.com/bugform.jsp


Registration
------------

Upon completion of your purchase of Puzzle Inlay, you will receive a license
name and license code combination. You will need to enter this information into
the registration dialog, and then click on "Enter License Information."

This game can be registered by clicking on the "Buy Now" button on the trial
dialog, or by visiting the GameHouse Store at: http://www.gamehouse.com/store/


About GameHouse
---------------

GameHouse, Inc. develops many games for the Internet, Windows, Macintosh and
other platforms such as Palm OS. To view the full complement of games available
and play free games online, visit: http://www.gamehouse.com/


Troubleshooting
---------------

This software has been tested extensively to make sure it will operate
correctly for all users. If you experience system crashes, error messages or
other incorrect behavior, we suggest you first try one of the following:

1) Upgrade your computer's sound card drivers. This can be done by identifying
the type of sound card your computer is using and finding the manufacturer's web
site. Or, most drivers will be automatically updated if you follow step #2.

2) Upgrade DirectX. This is a Microsoft component and it includes special
drivers for video cards and sound cards for virtually every manufacturer. It is
therefore a very large download, but updating DirectX solves nearly all system
problems encountered with GameHouse games.

DirectX Home Page: http://www.microsoft.com/directx/


Credits
-------

Puzzle Inlay was created at Puzzle Lab, with additional contribution from:

Garr Godfrey
Rodney Bambao
Chance Warner
Jason Katsanis
Teagen Densmore
Chuck Little
Brandon Godfrey
Kazunori Sasakura
